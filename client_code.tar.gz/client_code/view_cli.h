#ifndef _VIEW_CLI_H
#define _VIEW_CLI_H
//功能视图
void function();
//登录成功后进入聊天视图
void chat_show();
#endif
