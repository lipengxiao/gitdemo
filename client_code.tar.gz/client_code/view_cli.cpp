#include"view_cli.h"
#include<iostream>

using namespace std;

//功能视图
void function()
{
	cout<<"******myQQ测试版ver.1.0******"<<endl;
	cout<<"******1.注册新帐号***********"<<endl;
	cout<<"******2.登录  帐号***********"<<endl;
	cout<<"******3.单人  聊天***********"<<endl;
	cout<<"******4.退出  系统***********"<<endl;
	cout<<"*****************************"<<endl;
}
//chat_show()
void chat_show()
{
	cout<<"******功 能 界 面***********"<<endl;
	cout<<"******1.1 V 1聊天***********"<<endl;
	cout<<"******2.群     聊***********"<<endl;
	cout<<"******3.返回上一层**********"<<endl;
}
