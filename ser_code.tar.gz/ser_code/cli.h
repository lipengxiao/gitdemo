#ifndef _CLI_H
#define _CLI_H
Json::Value val;
val["TYPE"];
val["name"];
val["pw"];

#endif;
